import 'package:flutter/material.dart';

class GameMode3 extends StatelessWidget {
  const GameMode3({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: SizedBox.expand(
          child: DecoratedBox(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFF001F3F), Color(0xFF5292B9)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter)),
            child: Scaffold(
              backgroundColor: Colors.transparent,
              appBar: AppBar(
                toolbarHeight: 100,
                backgroundColor: const Color(0x4CEAD8B1),
                centerTitle: true,
                title: const Padding(
                  padding: EdgeInsets.fromLTRB(8.0, 20.0, 8.0, 8.0),
                  child: Text(
                    "MODE 3",
                    style: TextStyle(
                        fontFamily: 'Super Earthly',
                        fontSize: 70,
                        color: Color(0xFFEAD8B1),
                        shadows: [
                          Shadow(
                              color: Color(0xFF1E1E1E),
                              offset: Offset(3.0, 3.0),
                              blurRadius: 0.0),
                          Shadow(
                              color: Color(0xFF1E1E1E),
                              offset: Offset(3.0, -3.0),
                              blurRadius: 0.0),
                          Shadow(
                              color: Color(0xFF1E1E1E),
                              offset: Offset(-3.0, -3.0),
                              blurRadius: 0.0),
                          Shadow(
                              color: Color(0xFF1E1E1E),
                              offset: Offset(-3.0, 3.0),
                              blurRadius: 0.0)
                        ]),
                    textAlign: TextAlign.center,
                  ),
                ),
                leading: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Transform.translate(
                    offset: const Offset(25.0, 0.0),
                    child: Container(
                      width: 70,
                      height: 70,
                      decoration: const BoxDecoration(
                        color: Color(0xFFEAD8B1),
                        shape: BoxShape.circle,
                      ),
                      child: const Center(
                          child: Icon(Icons.arrow_back,
                              color: Color(0xFF1E1E1E), size: 50)),
                    ),
                  ),
                ),
                actions: [
                  Transform.translate(
                    offset: const Offset(-25.0, 0.0),
                    child: Image.asset('../assets/images/Logo.png'),
                  ),
                ],
              ),
              body: SizedBox.expand(
                child: DecoratedBox(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('../assets/images/image3.png'),
                        fit: BoxFit.fitHeight,
                        opacity: 0.3),
                  ),
                ),
              ),
            ),
          ),
        ));
  }
}
